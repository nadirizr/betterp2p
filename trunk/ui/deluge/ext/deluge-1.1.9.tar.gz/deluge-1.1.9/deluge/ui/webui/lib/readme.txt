This folder may only contain general purpose utilities/files/tools.
They should be usable outside of deluge.

Disclaimer:

Some may have been adapted to work better with deluge.
But they will not import other parts of deluge or Webui.

LICENCE:
All components are GPL compatible.
All these components are Licensed under their original license.
See docstring or LICENSE files.


