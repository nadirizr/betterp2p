#compatibility: use the included version/release of web.py.
from webpy022 import *
