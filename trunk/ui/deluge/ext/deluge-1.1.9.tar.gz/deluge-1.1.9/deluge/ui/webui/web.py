#compatibility: use the included version/release of web.py.
from lib.web import *
